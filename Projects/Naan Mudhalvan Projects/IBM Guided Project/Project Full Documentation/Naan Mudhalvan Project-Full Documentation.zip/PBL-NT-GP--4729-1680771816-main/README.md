# PBL-NT-GP--4729-1680771816
## **Dissecting the Digital Landscape: A Comprehensive Analysis of Social Media**
![social_media](https://github.com/naanmudhalvan-SI/PBL-NT-GP--4729-1680771816/assets/131850607/79ebe401-f6b0-46d0-9c34-bcb9b85bb03a)

## 📝 Project Description
Social media is a vast platform that contains an enormous amount of information, making it an excellent source for data analytics. By analyzing social media data, businesses can gain insights into consumer behavior, preferences, sentiments, and trends, which can aid in making informed decisions related to marketing and advertising strategies.

## 💻 Tech Stack

 - [Data Analysis with Python](https://en.wikipedia.org/wiki/Data_analysis)
 - [IBM Cloud](https://en.wikipedia.org/wiki/IBM_Cloud)
 - [IBM Watson](https://en.wikipedia.org/wiki/IBM_Watson)
 - [IBM Cognos Analytics](https://en.wikipedia.org/wiki/IBM_Cognos_Analytics)


## 💡 Project Design and Planning
 - [Ideation Phase](https://github.com/naanmudhalvan-SI/PBL-NT-GP--4729-1680771816/tree/main/Project%20Design%20Phases/Ideation)
 - [Project Design Phase I](https://github.com/naanmudhalvan-SI/PBL-NT-GP--4729-1680771816/tree/main/Project%20Design%20Phases/Project%20design/Project%20Design-%20Part%2001)
 - [Project Design Phase II](https://github.com/naanmudhalvan-SI/PBL-NT-GP--4729-1680771816/tree/main/Project%20Design%20Phases/Project%20design/Project%20design-%20Part%2002)
 - [Project Development Phase](https://github.com/naanmudhalvan-SI/PBL-NT-GP--4729-1680771816/tree/main/Project%20Development%20Phase)

## 👍 Social Impact
 - Influence on work Culture, Training, and Development
 - Influence on Society
 - The challenges of Social Media

## 💰 Business Impact
 - Social Media is used in powerful Marketing Strategies.
 - Users in Social Media shares valuable informations.
 - People use social media to build their image.
   
   ![image_processing20200103-17071-1yb56eg](https://github.com/naanmudhalvan-SI/PBL-NT-GP--4729-1680771816/assets/131850607/cbbca521-ec22-4dd9-b09b-04d6e76f4cd3)

## 💫 Project Contributors

Team Id : NM2023TMID17232
- [@Pavithra](https://github.com/pavik0413)

## 📄 Project Documentation

- [Click Here To View](https://github.com/naanmudhalvan-SI/PBL-NT-GP--4729-1680771816/blob/main/Final%20Deliverables/A%20Comprehensive%20Analysis%20of%20Social%20Media.pdf)


## 🔗 Project Demonstration Video Direct Link (With Audio)

https://youtu.be/XOOaRMKuWUo


## 🌐 Webpage To View Analyzed Visualizations
https://pavithrakcse.wixsite.com/a-comprehensive-anal

## 🤝 Support

For support, please reach out to us at email pavithrakcse@gmail.com

![Logo](https://media1.giphy.com/media/l3q2FnW3yZRJVZH2g/giphy.gif?cid=790b7611df04fcf78be01764e6121ed07c106223750aabd6&rid=giphy.gif&ct=g)


**********|**| 🎓 Krishnasamy College Of Engineering And Technology |**|**********
